package com.mycompany.fitnesstracker;

import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Scanner;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class FitnessTracker {
    private static final String FILE_PATH = "UserDetails.json";
    private static ArrayList<NewUser> UserDetails = new ArrayList<>();
    private static Scanner scanner = new Scanner(System.in);

//parent class    
    static class NewUser {
        public String userName;
        public int userAge;
        public double userHeight;
        public double userWeight;
        public String workoutGoals;
        public ArrayList<DailyData> dailyData = new ArrayList<>();
    }
//inner classes
    static class DailyData {
        public String date;
        public ArrayList<Workout> dailyWorkouts = new ArrayList<>();

        public DailyData(String date) {
            this.date = date;
        }
    }
    static class Workout {
        public String name;
        public int duration;
//constructors
        public Workout(String name, int duration) {
            this.name = name;
            this.duration = duration;
        }
    }

    public static void saveUserDetailsToJson() {
        JSONArray jsonArray = new JSONArray();

        for (NewUser nu : UserDetails) {
            JSONObject obj = new JSONObject();
            obj.put("userName", nu.userName); 
            obj.put("userAge", nu.userAge);
            obj.put("userHeight", nu.userHeight);
            obj.put("userWeight", nu.userWeight);
            obj.put("workoutGoals", nu.workoutGoals);

            JSONArray dailyDataArray = new JSONArray();
            for (DailyData daily : nu.dailyData) {
                JSONObject dailyObj = new JSONObject();
                dailyObj.put("date", daily.date);
                
                JSONArray workoutsArray = new JSONArray();
                for (Workout workout : daily.dailyWorkouts) {
                    JSONObject workoutObj = new JSONObject();
                    workoutObj.put("name", workout.name);
                    workoutObj.put("duration", workout.duration);
                    workoutsArray.put(workoutObj);
                }
                dailyObj.put("workouts", workoutsArray);
                dailyDataArray.put(dailyObj);
            }
            obj.put("dailyData", dailyDataArray);
            
            jsonArray.put(obj);
        }

        try (FileWriter file = new FileWriter(FILE_PATH)) {
            file.write(jsonArray.toString(4));
        } catch (IOException e) {
            System.out.println("File saving unsuccessful: " + e.getMessage());
        }
    }

    public static void loadUserDetailsFromJsonFile() {
        try {
            if (!Files.exists(Paths.get(FILE_PATH))) {
                return;
            }

            String filecontent = Files.readString(Paths.get(FILE_PATH));
            JSONArray jsonArray = new JSONArray(filecontent);
            UserDetails.clear();

            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject obj = jsonArray.getJSONObject(i);
                NewUser user = new NewUser();

                user.userName = obj.getString("userName"); 
                user.userAge = obj.getInt("userAge");
                user.userHeight = obj.getDouble("userHeight");
                user.userWeight = obj.getDouble("userWeight");
                user.workoutGoals = obj.getString("workoutGoals");

                
                if (obj.has("dailyData")) {
                    JSONArray dailyDataArray = obj.getJSONArray("dailyData");
                    for (int j = 0; j < dailyDataArray.length(); j++) {
                        JSONObject dailyObj = dailyDataArray.getJSONObject(j);
                        DailyData daily = new DailyData(dailyObj.getString("date"));
                        
                        
                        if (dailyObj.has("workouts")) {
                            JSONArray workoutsArray = dailyObj.getJSONArray("workouts");
                            for (int k = 0; k < workoutsArray.length(); k++) {
                                JSONObject workoutObj = workoutsArray.getJSONObject(k);
                                Workout workout = new Workout(
                                    workoutObj.getString("name"),
                                    workoutObj.getInt("duration")
                                );
                                daily.dailyWorkouts.add(workout);
                            }
                        }
                        user.dailyData.add(daily);
                    }
                }

                UserDetails.add(user);
            }

        } catch (IOException | JSONException e) {
            System.out.println("Error loading from JSON file: " + e.getMessage());
        }
    }

    public static void captureUserDetails() {
        NewUser newUser = new NewUser();
        scanner.nextLine();
        
        System.out.println("\n Enter user profile information");
        System.out.print("Enter your name: ");
        newUser.userName = scanner.nextLine();
        
        System.out.print("Enter your age: ");
        newUser.userAge = scanner.nextInt();
        
        System.out.print("Enter your height (cm): ");
        newUser.userHeight = scanner.nextDouble();
        
        System.out.print("Enter your weight (kg): ");
        newUser.userWeight = scanner.nextDouble();
        
        scanner.nextLine(); 
        System.out.print("Enter your workout goals: ");
        newUser.workoutGoals = scanner.nextLine();
        
        UserDetails.clear();
        UserDetails.add(newUser);
        saveUserDetailsToJson();
        System.out.println("User profile created successfully!");
    }

    public static void updateWeight() {
        if (UserDetails.isEmpty()) {
            System.out.println("No user profile found. Please create a profile first.");
            return;
        }
        
        NewUser user = UserDetails.get(0);
        System.out.println("\n Update weight ");
        System.out.println("Current weight: " + user.userWeight + " kg");
        System.out.print("Enter new weight (kg): ");
        
        double newWeight = scanner.nextDouble();
        user.userWeight = newWeight;
        
        saveUserDetailsToJson();
        System.out.println("Weight updated successfully to: " + newWeight + " kg");
    }

    public static void deleteUserDetails() {
        if (UserDetails.isEmpty()) {
            System.out.println("No user profile found.");
            return;
        }
        
        System.out.println("\n DELETE PROFILE");
        System.out.print("Are you sure you want to delete your profile? (yes/no): ");
        String confirmation = scanner.nextLine();

if (confirmation.equalsIgnoreCase("yes")) {
    UserDetails.clear();
    try {
        Files.deleteIfExists(Paths.get(FILE_PATH));
        System.out.println("Profile deleted successfully.");
    } catch (IOException e) {
        System.out.println("Error deleting profile. " + e.getMessage());
    }
} else {
    System.out.println("Profile deletion cancelled.");
}

    }

    public static void printProfile() {
        if (UserDetails.isEmpty()) {
            System.out.println("No user profile found.");
            return;
        }
        
        NewUser user = UserDetails.get(0);
        System.out.println("\n Profile details ");
        System.out.println("Name: " + user.userName);
        System.out.println("Age: " + user.userAge + " years");
        System.out.println("Height: " + user.userHeight + " cm");
        System.out.println("Weight: " + user.userWeight + " kg");
        System.out.println("Workout Goals: " + user.workoutGoals);
    }

    public static void addDailyWorkout() {
        if (UserDetails.isEmpty()) {
            System.out.println("No user profile found. Please create a profile first.");
            return;
        }
        
        NewUser user = UserDetails.get(0);
        
        System.out.println("\n Add daily workout");
        
        scanner.nextLine(); 
        
        System.out.print("Enter date (YYYY-MM-DD): ");
        String date = scanner.nextLine();
        
        System.out.print("Enter workout name: ");
        String name = scanner.nextLine();
        
        System.out.print("Enter duration (minutes): ");
        int duration = scanner.nextInt();
        scanner.nextLine(); 
        
        DailyData daily = null;
        for (DailyData d : user.dailyData) {
            if (d.date.equals(date)) {
                daily = d;
                break;
            }
        }
        
        if (daily == null) {
            daily = new DailyData(date);
            user.dailyData.add(daily);
        }
        
        Workout newWorkout = new Workout(name, duration);
        daily.dailyWorkouts.add(newWorkout);
        
        System.out.println("Workout added successfully for " + date);
        saveUserDetailsToJson();
    }

    public static void viewWorkoutHistory() {
        if (UserDetails.isEmpty()) {
            System.out.println("No user profile found.");
            return;
        }
        
        NewUser user = UserDetails.get(0);
        
        if (user.dailyData.isEmpty()) {
            System.out.println("No workout history found.");
            return;
        }

        System.out.println("\n Workout History ");
        
        for (DailyData daily : user.dailyData) {
            System.out.println("\nDate: " + daily.date);
            System.out.println("Workouts:");
            System.out.println("Name\t\tDuration (min)");
            
            int dailyTotal = 0;
            for (Workout workout : daily.dailyWorkouts) {
                System.out.println(workout.name + "\t\t" + workout.duration);
                dailyTotal += workout.duration;
            }
            System.out.println("Daily Total: " + dailyTotal + " minutes");
        }
    }    
    
    //Main Menu
    public static void runApplication() {
        while (true) {
            System.out.println("\n 📋 MENU:");
            System.out.println("1. Enter User information");
            System.out.println("2. Update weight");
            System.out.println("3. Delete profile");
            System.out.println("4. Profile details");
            System.out.println("5. Add daily workout");
            System.out.println("6. View workout history"); 
            System.out.println("7. Exit application");
            System.out.print("Enter your choice: ");

            String input = scanner.nextLine();

            switch (input) {
                case "1":
                    captureUserDetails();
                    break;
                case "2":
                    updateWeight();
                    break;
                case "3":
                    deleteUserDetails();
                    break;
                case "4":
                    printProfile();
                    break;
                case "5":
                    addDailyWorkout(); 
                    break;
                case "6":
                    viewWorkoutHistory(); 
                    break;
                case "7":
                    System.out.println("Exiting application.");
                    return;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }
    
    //Helpers for JUnit testing
   
public static void clearUserDetailsForTesting() {
    UserDetails.clear();
}

public static ArrayList<NewUser> getUserDetails() {
    return UserDetails;
}

public static void deleteUserDetailsForTesting(boolean confirm) {
    if (confirm) UserDetails.clear();
}

public static void updateWeightForTesting(double newWeight) {
    if (!UserDetails.isEmpty() && newWeight > 0) {
        UserDetails.get(0).userWeight = newWeight;
    }
}

    public static void main(String[] args) {
        loadUserDetailsFromJsonFile();
        runApplication();
    }
}