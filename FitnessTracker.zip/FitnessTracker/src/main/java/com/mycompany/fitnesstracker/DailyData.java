/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.fitnesstracker;

import java.util.ArrayList;

public class DailyData {
    public String date;
    public ArrayList<Workout> dailyWorkouts = new ArrayList<>();
    
    public DailyData(String date) {
        this.date = date;
    }
}