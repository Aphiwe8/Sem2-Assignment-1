/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.fitnesstracker;

import java.util.ArrayList;

public class NewUser {
    public String userName;
    public int userAge;  
    public double userHeight;
    public double userWeight;
    public String workoutGoals; 
    public ArrayList<DailyData> workouts = new ArrayList<>();

    class dailyData {

        public dailyData() {
        }
    }
}
