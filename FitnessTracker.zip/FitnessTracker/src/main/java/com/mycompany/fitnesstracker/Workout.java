/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.fitnesstracker;

public class Workout {
    public String name;
    public int duration; // in minutes
    
    public Workout(String name, int duration) {
        this.name = name;
        this.duration = duration;
    }
}

