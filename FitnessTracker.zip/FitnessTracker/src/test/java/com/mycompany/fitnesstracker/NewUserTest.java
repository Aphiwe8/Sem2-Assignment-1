/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.fitnesstracker;

import java.util.ArrayList;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author lab_services_student
 */
public class NewUserTest {
    
    public NewUserTest() {
    }

    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    FitnessTracker.clearUserDetailsForTesting();

    }
    
    @AfterEach
    public void tearDown() {
    }
    
    //Helper methods
    
    public void addTestUser(String name, int age, double height, double weight, String goal) {
        FitnessTracker.NewUser user = new FitnessTracker.NewUser();
        user.userName = name;
        user.userAge = age;
        user.userHeight = height;
        user.userWeight = weight;
        user.workoutGoals = goal;
        FitnessTracker.getUserDetails().add(user);
    }

    public void addDailyWorkoutTest(String date, String name, int duration) {
        FitnessTracker.NewUser user = FitnessTracker.getUserDetails().get(0);
        FitnessTracker.DailyData daily = new FitnessTracker.DailyData(date);
        
        daily.dailyWorkouts.add(new FitnessTracker.Workout(name, duration));
        user.dailyData.add(daily);
    }

    
    //Search Tests
    
    @Test
    public void testValidProfileDetails() {
        addTestUser("Amahle", 25, 165.0, 60.0, "Weight loss");
        FitnessTracker.NewUser user = FitnessTracker.getUserDetails().get(0);
        assertEquals("Amahle", user.userName);
        assertEquals(25, user.userAge);
        assertEquals(165.0, user.userHeight);
        assertEquals(60.0, user.userWeight);
        assertEquals("Weight loss", user.workoutGoals);
    }

    @Test
    public void testValidDailyDataByDate() {
        addTestUser("Mick", 30, 175.0, 75.0, "Muscle gain");
        addDailyWorkoutTest("2025-09-03", "Running", 30);
        FitnessTracker.DailyData daily = FitnessTracker.getUserDetails().get(0).dailyData.get(0);
        assertEquals("2025-09-03", daily.date);
        assertEquals("Running", daily.dailyWorkouts.get(0).name);
        assertEquals(30, daily.dailyWorkouts.get(0).duration);
    }

    @Test
    public void testValidWorkoutHistory() {
        addTestUser("Bruce", 28, 170.0, 68.0, "Endurance");
        addDailyWorkoutTest("2025-09-03", "Cycling", 45);
        ArrayList<FitnessTracker.DailyData> history = FitnessTracker.getUserDetails().get(0).dailyData;
        assertFalse(history.isEmpty());
        assertEquals(1, history.size());
        assertEquals("Cycling", history.get(0).dailyWorkouts.get(0).name);
    }

    @Test
    public void testInvalidWorkoutHistory() {
        addTestUser("Wayne", 22, 160.0, 55.0, "Fat loss");
        ArrayList<FitnessTracker.DailyData> history = FitnessTracker.getUserDetails().get(0).dailyData;
        assertTrue(history.isEmpty(), "No workout History");
    }

    @Test
    public void testValidDeleteProfile() {
        addTestUser("Raven", 26, 168.0, 62.0, "Muscle gain");
        FitnessTracker.deleteUserDetailsForTesting(true);
        assertTrue(FitnessTracker.getUserDetails().isEmpty());
    }

    @Test
    public void testInvalidDeleteProfile() {
        addTestUser("Robin", 35, 180.0, 80.0, "Endurance");
        FitnessTracker.deleteUserDetailsForTesting(false);
        assertFalse(FitnessTracker.getUserDetails().isEmpty());
    }

    @Test
    public void testValidUpdateWeight() {
        addTestUser("Star", 24, 165.0, 60.0, "Fat loss");
        FitnessTracker.updateWeightForTesting(65.0);
        assertEquals(65.0, FitnessTracker.getUserDetails().get(0).userWeight);
    }

    @Test
    public void testInvalidUpdateWeight() {
        addTestUser("Artemis", 29, 172.0, 70.0, "Muscle gain");
        FitnessTracker.updateWeightForTesting(-5.0); 
        assertEquals(70.0, FitnessTracker.getUserDetails().get(0).userWeight);
    }
}
   
