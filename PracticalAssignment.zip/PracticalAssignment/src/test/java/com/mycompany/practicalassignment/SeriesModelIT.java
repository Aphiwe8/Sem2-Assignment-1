/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.practicalassignment;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;



public class SeriesModelIT {
    
    public SeriesModelIT() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
        PracticalAssignment.clearSeriesList();
    }
    
    @AfterEach
    public void tearDown() {
    }
    
// Search Tests
    
    @Test 
    public void testSearchSeries() {
        PracticalAssignment.addSeriesForTest("111", "One Piece", 12, 56);
    boolean found = false;
        for (PracticalAssignment.SeriesModel s : PracticalAssignment.getSeriesList()) {
    if (s.seriesID.equals("111")) {
        found = true;
        break;
    }
    }
        assertTrue(found);
    }
    
    @Test 
    public void testSearchSeries_SeriesNotFound() {
        PracticalAssignment.addSeriesForTest("111", "One Piece", 12, 56);
    boolean found = false;
        for (PracticalAssignment.SeriesModel s : PracticalAssignment.getSeriesList()) {
    if (s.seriesID.equals("S88")) {
        found = true;
        break;
    }
    }
        assertFalse(found);
    }
    
    @Test 
    public void testUpdateSeries() {
        PracticalAssignment.addSeriesForTest("111", "One Piece", 12, 56);
        PracticalAssignment.getSeriesList().get(0).seriesAge = 16;

        assertEquals(16, PracticalAssignment.getSeriesList().get(0).seriesAge,
                "Age updated to 16.");
    }
    
    @Test
public void testDeleteSeries_Found() {
    
    PracticalAssignment.addSeriesForTest("111", "One Piece", 12, 56);
    boolean removed = false;
    
    for (int i = 0; i < PracticalAssignment.getSeriesList().size(); i++) {
        if (PracticalAssignment.getSeriesList().get(i).seriesID.equals("111")) {
            PracticalAssignment.getSeriesList().remove(i);
            removed = true;
            break;
        }
    }
    assertTrue(removed, "Series 111 is deleted.");
    assertEquals(0, PracticalAssignment.getSeriesList().size(), "List is empty");
}

@Test
public void testDeleteSeries_SeriesNotFound() {

    PracticalAssignment.addSeriesForTest("111", "One Piece", 12, 56);
    boolean removed = false;
    
    for (int i = 0; i < PracticalAssignment.getSeriesList().size(); i++) {
        if (PracticalAssignment.getSeriesList().get(i).seriesID.equals("S88")) {
            PracticalAssignment.getSeriesList().remove(i);
            removed = true;
            break;
        }
    }
    assertFalse(removed);
    assertEquals(1, PracticalAssignment.getSeriesList().size());
}

    @Test 
    public void testAgeRestriction_AgeValid() {
        assertTrue(PracticalAssignment.isAgeValid(2));
        assertTrue(PracticalAssignment.isAgeValid(10));
        assertTrue(PracticalAssignment.isAgeValid(18));
    } 
    
    @Test 
    public void testAgeRestriction_SeriesAgeInvalid() {
        assertFalse(PracticalAssignment.isAgeValid(1));
        assertFalse(PracticalAssignment.isAgeValid(19));
        assertFalse(PracticalAssignment.isAgeValid(-5));
    }
    
  
}
