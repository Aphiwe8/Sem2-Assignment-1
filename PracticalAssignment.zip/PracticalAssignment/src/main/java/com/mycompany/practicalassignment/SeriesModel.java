/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.practicalassignment;

class SeriesModel {
    public String seriesID;
    public String seriesName;
    public int seriesAge;
    public int seriesNumberOfEpisodes;
    
    //constructor
    SeriesModel(String id, String name, int age, int episodes){
        this.seriesID = id;
        this.seriesName = name;
        this.seriesAge = age;
        this.seriesNumberOfEpisodes = episodes;
        
    }
    
}