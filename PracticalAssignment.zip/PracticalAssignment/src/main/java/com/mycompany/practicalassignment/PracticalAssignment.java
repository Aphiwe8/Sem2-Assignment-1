package com.mycompany.practicalassignment;

import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Scanner;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class PracticalAssignment {    
    
    static class SeriesModel {
        public String seriesID;
        public String seriesName;
        public int seriesAge;
        public int seriesNumberOfEpisodes;

        public SeriesModel() {
        }
        
//constructor 
        public SeriesModel(String id, String name, int age, int episodes) {
            this.seriesID = id;
            this.seriesName = name;
            this.seriesAge = age;
            this.seriesNumberOfEpisodes = episodes;
        }
    }

    static String FILE_PATH = "captureseries.json";
    private static ArrayList<SeriesModel> seriesList = new ArrayList<>();
    private static Scanner scanner = new Scanner(System.in);

    public static void saveSeriesListToJson() {
        JSONArray jsonArray = new JSONArray();

        for (SeriesModel sm : seriesList) {
            JSONObject obj = new JSONObject();
            obj.put("seriesID", sm.seriesID);
            obj.put("seriesName", sm.seriesName);
            obj.put("seriesAge", sm.seriesAge);
            obj.put("seriesNumberOfEpisodes", sm.seriesNumberOfEpisodes);
            jsonArray.put(obj);
        }

        try (FileWriter file = new FileWriter(FILE_PATH)) {
            file.write(jsonArray.toString(4));
        } catch (IOException e) {
            System.out.println("File saving unsuccessful: " + e.getMessage());
        }
    }

    public static void loadSeriesListFromJsonFile() {
        try {
            if (!Files.exists(Paths.get(FILE_PATH))) {
                return;
            }

            String filecontent = Files.readString(Paths.get(FILE_PATH));
            JSONArray jsonArray = new JSONArray(filecontent);
            seriesList.clear();

            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject obj = jsonArray.getJSONObject(i);
                SeriesModel series = new SeriesModel();
                
                series.seriesID = obj.getString("seriesID");
                series.seriesName = obj.getString("seriesName");
                series.seriesAge = obj.getInt("seriesAge");
                series.seriesNumberOfEpisodes = obj.getInt("seriesNumberOfEpisodes");

                seriesList.add(series);
            }

        } catch (IOException | JSONException e) {
            System.out.println("Error loading from JSON file: " + e.getMessage());
        }
    }

    public static void captureSeries() {
        System.out.print("Enter Series ID: ");
        String id = scanner.nextLine();

        System.out.print("Enter Series Name: ");
        String name = scanner.nextLine();

        int age = 0;
        while (true) {
            try {
                System.out.print("Enter Age Restriction (2-18): ");
                age = Integer.parseInt(scanner.nextLine());

                if (age >= 2 && age <= 18) {
                    break;
                } else {
                    System.out.println("Age must be between 2 and 18.");
                }
            } catch (Exception e) {
                System.out.println("Invalid input. Please enter a number.");
            }
        }

        int episodes = 0;
        while (true) {
            try {
                System.out.print("Enter number of episodes: ");
                episodes = Integer.parseInt(scanner.nextLine());
                break;
            } catch (Exception e) {
                System.out.println("Invalid input. Please enter a number.");
            }
        }

        SeriesModel sm = new SeriesModel(id, name, age, episodes);
        seriesList.add(sm);
        saveSeriesListToJson();
        System.out.println("Series details saved successfully.");
    }

    public static void searchSeries() {
        System.out.print("Enter Series ID to search: ");
        String id = scanner.nextLine();

        for (SeriesModel sm : seriesList) {
            if (sm.seriesID.equals(id)) {
                System.out.println("Search Results:");
                System.out.println("ID: " + sm.seriesID);
                System.out.println("Name: " + sm.seriesName);
                System.out.println("Age Restriction: " + sm.seriesAge);
                System.out.println("Episodes: " + sm.seriesNumberOfEpisodes);
                return;
            }
        }
        System.out.println("No series found with ID: " + id);
    }

    public static void updateSeriesAge() {
        System.out.print("Enter Series ID to update age restriction: ");
        String id = scanner.nextLine();

        for (SeriesModel sm : seriesList) {
            if (sm.seriesID.equals(id)) {
                while (true) {
                    try {
                        System.out.print("Enter new Age Restriction (2-18): ");
                        int newAge = Integer.parseInt(scanner.nextLine());

                        if (newAge >= 2 && newAge <= 18) {
                            sm.seriesAge = newAge;
                            saveSeriesListToJson();
                            System.out.println("Age restriction updated successfully.");
                            return;
                        } else {
                            System.out.println("Age must be between 2 and 18.");
                        }
                    } catch (Exception e) {
                        System.out.println("Invalid input. Please enter a number.");
                    }
                }
            }
        }
        System.out.println("No series found with ID: " + id);
    }

    public static void deleteSeries() {
        System.out.print("Enter Series ID to delete: ");
        String id = scanner.nextLine();

        for (SeriesModel sm : seriesList) {
            if (sm.seriesID.equals(id)) {
                System.out.print("Are you sure you want to delete this series? (yes/no): ");
                String confirm = scanner.nextLine();

                if (confirm.equalsIgnoreCase("yes")) {
                    seriesList.remove(sm);
                    saveSeriesListToJson();
                    System.out.println("Series deleted successfully.");
                }
                return;
            }
        }
        System.out.println("No series found with ID: " + id);
    }
    
    public static void printReport() {
        System.out.println("\n📄 Series Report - 2025\n");

        if (seriesList.isEmpty()) {
            System.out.println("No series available.");
        } else {
            for (SeriesModel sm : seriesList) {
                System.out.println("ID: " + sm.seriesID);
                System.out.println("Name: " + sm.seriesName);
                System.out.println("Age Restriction: " + sm.seriesAge);
                System.out.println("Episodes: " + sm.seriesNumberOfEpisodes);
            }
        }
    }

    public static void listSeriesTitles() {
        if (seriesList.isEmpty()) {
            System.out.println("No series in the list.");
            return;
        }

        System.out.println("\nSeries Titles:");
        for (SeriesModel sm : seriesList) {
            System.out.println("ID: " + sm.seriesID + " | Name: " + sm.seriesName);
        }
    }

    public static void countSeries() {
        int count = seriesList.size();
        System.out.println("Total number of series: " + count);
    }

    public static void sortSeriesByName() {
        if (seriesList.isEmpty()) {
            System.out.println("No series to sort.");
            return;
        }

        seriesList.sort((s1, s2) -> s1.seriesName.compareToIgnoreCase(s2.seriesName));
        System.out.println("Series sorted by name (A-Z).");
        printReport();
    }

    // Main menu
    public static void runApplication() {
        while (true) {
            System.out.println("\n📋 MENU - Select an option:");
            System.out.println("1. Capture a new series");
            System.out.println("2. Search for a series");
            System.out.println("3. Update series age restriction");
            System.out.println("4. Delete a series");
            System.out.println("5. Print series report - 2025");
            System.out.println("6. Exit Application");
            System.out.println("7. List all series titles");
            System.out.println("8. Count total series");
            System.out.println("9. Sort series by name (A-Z)");
            System.out.print("Enter your choice: ");

            String input = scanner.nextLine();

            switch (input) {
                case "1":
                    captureSeries();
                    break;
                case "2":
                    searchSeries();
                    break;
                case "3":
                    updateSeriesAge();
                    break;
                case "4":
                    deleteSeries();
                    break;
                case "5":
                    printReport();
                    break;
                case "6":
                    System.out.println("Exiting application.");
                    return;
                case "7":
                    listSeriesTitles();
                    break;
                case "8":
                    countSeries();
                    break;
                case "9":
                    sortSeriesByName();
                    break;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }
      
//Helper methods for Junit tests
    
    public static void clearSeriesList() {
        seriesList.clear();
    }

    public static void addSeriesForTest(String id, String name, int age, int episodes) {
        SeriesModel sm = new SeriesModel(id, name, age, episodes);
        seriesList.add(sm);
    }

    public static ArrayList<SeriesModel> getSeriesList() {
        return seriesList;
    }

    public static boolean isAgeValid(int age) {
        return age >= 2 && age <= 18;
    }

    public static void main(String[] args) {
        loadSeriesListFromJsonFile();
        runApplication();
    }
}